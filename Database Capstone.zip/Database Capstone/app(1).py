from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from os import environ
import psycopg2

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('DB_URL')
db = SQLAlchemy(app)

def get_db_connection():
    conn = psycopg2.connect(host='127.0.0.1',
                            database='mmwave',
                            user='mmwave',
                            password='TImmwave2025!')
    return conn


@app.route('/')
def index():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT id,vec::text::jsonb,tag FROM featurels LIMIT 500;')
    books = cur.fetchall()
    cur.close()
    conn.close()
    return make_response(jsonify(books),200)
if __name__ == '__main__':
    app.run()
