# General Library Imports
import copy
import string
import math
import pandas as pd
import psycopg2
import json
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F
import os
import sys
import csv
from pathlib import Path
import time 
BINARY_CLASSIFIER_ENABLE = 0


# Local Imports
from Demo_Classes.people_tracking import PeopleTracking
from gui_common import (
    NUM_CLASSES_IN_CLASSIFIER,
    TAG_HISTORY_LEN,
    CLASSIFIER_CONFIDENCE_SCORE,
    MIN_CLASSIFICATION_VELOCITY,
    TAG_HISTORY_LEN,
    MAX_NUM_UNKNOWN_TAGS_FOR_HUMAN_DETECTION,
    PROBABILITY_THRESHOLDS,
    COUNT_THRESHOLDS,
    PURE_MODEL_ENABLE,
    VDB_IP,
    VDB_QUERY_RATE,
    VDB_DISTANCE,
    VDB_LENGTH,
)

predictions_csv = "predictions_log.csv"
feature_csv = "feature_log.csv"


# Create a new CSV file and write the header row
with open(predictions_csv, mode='w', newline='') as prediction_file:
    writer = csv.writer(prediction_file)
    writer.writerow(['local time', 'trackID', 'AI_model_prediction', 'VDB_prediction', 'post_proc_label' , "Binary label", "VDB Query", "VDB Override", 'probabilities', 'Count buffer'])
# Create a new CSV file
with open(feature_csv, mode='w', newline='') as feature_file:
    writer = csv.writer(feature_file)

#determine whether to connect to the database
database_is_open = False

if (VDB_IP != 'ignore'):
#while(not(database_is_open)): 
    #VDB_IP = input("Enter the database host IP (if database is not in use, type ignore): ")
    #if (VDB_IP == 'ignore'):
    #    break
    try:
        connection = psycopg2.connect(
        user='mmwave',
        password='TImmwave2025!',
        host= VDB_IP,    #always will be changed, since i dont have the cloud open 24/7 yet
        port='443',
        database='mmwave'
        )
        print("Database connected")
        database_is_open = True
    except psycopg2.Error as e:
        database_is_open = False
        print(f"Error connecting to the database: {e}")

class CNN1D(nn.Module):
    def __init__(self, input_size, num_classes):
        super(CNN1D, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=16, kernel_size=3, padding=1)
        self.relu1 = nn.ReLU()
        self.norm1 = nn.BatchNorm1d(16)
        self.dropout1 = nn.Dropout(0.3)
        self.conv2 = nn.Conv1d(in_channels=16, out_channels=32, kernel_size=3, padding=1)
        self.relu2 = nn.ReLU()
        self.norm2 = nn.BatchNorm1d(32)
        self.dropout2 = nn.Dropout(0.3)
        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(32, num_classes)
    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.norm1(x)
        x = self.dropout1(x)
        x = self.conv2(x)
        x = self.relu2(x)
        x = self.norm2(x)
        x = self.dropout2(x)
        x = self.global_avg_pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x
sys.modules['__main__'].CNN1D = CNN1D  # Register class in the main module
#Load the python model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#path containing DEMO_full_model.pth
model_path = str(Path.cwd()) + "\\Model.pth" #os.path.join(sys.path[0], "Model.pth")
model = torch.load(model_path, map_location=device, weights_only=False)
model.eval()

# Logger
import logging
log = logging.getLogger(__name__)


class OOBx432(PeopleTracking):
    def __init__(self):
        PeopleTracking.__init__(self)
        self.featureDatabaseDict = {}
        self.all_target_features = None
        self.local_time_string = None
        self.classCounts = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
        self.binaryOutput = None
        self.database_queried = [None, None, None]
        self.database_override = [None, None, None]
        self.vdbClass = [None, None, None]
        self.most_common_tag = None
        self.binaryLabel = [None,None,None]
        self.mostFrequentClass = [None, None, None]
        self.frameCount = 0
        self.wasTargetHuman = [0, 0, 0]
        self.modelClass = [None, None, None]
        self.probabilityStr = [None, None, None]
        
        
        
    def updateGraph(self, outputDict):
        PeopleTracking.updateGraph(self, outputDict)
        predicted_class = None        
        # Update boundary box colors based on results of Occupancy State Machine
        if ('enhancedPresenceDet' in outputDict):
            enhancedPresenceDet = outputDict['enhancedPresenceDet']
            for box in self.boundaryBoxViz:
                if ('mpdBoundary' in box['name']):
                    # Get index of the occupancy zone from the box name
                    boxIdx = int(box['name'].lstrip(string.ascii_letters))
                    # out of bounds
                    if (boxIdx >= len(enhancedPresenceDet)):
                        log.warning("Warning : Occupancy results for box that does not exist")
                    elif (enhancedPresenceDet[boxIdx] == 0):
                        self.changeBoundaryBoxColor(box, 'b') # Zone unoccupied
                    elif (enhancedPresenceDet[boxIdx] == 1):
                        self.changeBoundaryBoxColor(box, 'y') # Minor Motion Zone Occupancy 
                    elif (enhancedPresenceDet[boxIdx] == 2):
                        self.changeBoundaryBoxColor(box, 'r') # Major Motion Zone Occupancy
                    else:
                        log.error("Invalid result for Enhanced Presence Detection TLV")


        # Classifier
        for cstr in self.classifierStr:
            cstr.setVisible(False)

        # Hold the track IDs detected in the current frame
        trackIDsInCurrFrame = []
        classifierOutput = None
        tracks = None
        result = None
        output = None
        self.frameCount += 1
        if ('classifierOutput' in outputDict):
            binaryOutput = outputDict['classifierOutput']
        classifierOutput = [[0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0]]
        if ('trackData' in outputDict):
            tracks = outputDict['trackData']
        if ('classifierFeatures' in outputDict):
            self.all_target_features = outputDict['classifierFeatures']
        currTracks = []
        prevTracks = []

        if ((self.all_target_features is not None) and (tracks is not None)):
            for trackNum, trackName in enumerate(tracks):
                trackID = int(trackName[0])
                # Reset per-frame VDB state
                self.vdbClass[trackID] = None
                self.database_queried[trackID] = None
                self.database_override[trackID] = None

                currTracks.append(trackID) #make an array of trackIDs used in a frame
                unusedTracks = set(prevTracks) - set(currTracks) #tracks that are not used and will be deleted
                #delete the unused tracks
                for trackID in unusedTracks:
                    print(f"Track {trackID} is no longer used.")
                    if trackID in self.featureDatabaseDict:
                        del self.featureDatabaseDict[trackID]
                if trackID in self.featureDatabaseDict: #if the track with a classifier exists already, start adding features
                    # append features
                    self.featureDatabaseDict[trackID].append(self.all_target_features[trackNum][0])
                    self.featureDatabaseDict[trackID].append(self.all_target_features[trackNum][1])
                    self.featureDatabaseDict[trackID].append(self.all_target_features[trackNum][2])
                    self.featureDatabaseDict[trackID].append(self.all_target_features[trackNum][3])

                    if len(self.featureDatabaseDict[trackID])  > 80:
                        self.featureDatabaseDict[trackID].pop(0)
                        self.featureDatabaseDict[trackID].pop(0)
                        self.featureDatabaseDict[trackID].pop(0)
                        self.featureDatabaseDict[trackID].pop(0)
                else:
                    self.featureDatabaseDict[trackID] = self.all_target_features[trackNum] #create new trackID for identified track
                    print("Successfully identified new track")


                if len(self.featureDatabaseDict[trackID])  == 80:
                    
                    #classifier model prediction
                    #set live sample to 1D 80 column numpy array
                    live_sample = np.array(self.featureDatabaseDict[trackID])

                    #dimension checking & reshaping of input data
                    if live_sample.ndim == 1:
                        live_sample = live_sample.reshape(1, -1)  #shape is (1,80), 2D array in form of rows and columns instead of a list of 80 floats

                    #should be constants
                    features_per_frame = 4
                    num_frames = live_sample.shape[1] // features_per_frame  #80 // 4 = 20

                    #reshape the live data into (batch, num_frames, features_per_frame)
                    reshaped_live_data = live_sample.reshape(-1, num_frames, features_per_frame) #shape is (1,20,4)
                    input_data = np.transpose(reshaped_live_data, (0, 2, 1)) #shape is converted to (1,4,20) to put into model

                    input_tensor = torch.tensor(input_data, dtype=torch.float32)
                    #print(input_tensor)
                    output = model(input_tensor)
                    #print(output)
                    probabilities = F.softmax(output, dim=1).tolist()
                    classifierOutput[trackNum] = probabilities[0]
                    #print("Probabilities:", probabilities)

                    self.modelClass[trackID] = output.argmax(dim=1).item()
                    current_time = time.time()
                    self.local_time_string = time.ctime(current_time)
                    if self.modelClass[trackID] == 0:
                        classifierLabel = "human"
                    elif self.modelClass[trackID] == 1:
                        classifierLabel = "pet"
                    elif self.modelClass[trackID] == 2:
                        classifierLabel = "fan"
                    elif self.modelClass[trackID] == 3:
                        classifierLabel = "roomba"
                    else:
                        classifierLabel = "Unknown"
                    #add to tag list
                    self.classifierTags[trackID].appendleft(self.modelClass[trackID])
                    #use the end of currTracks to make the prevTracks array to be used 
                    prevTracks = currTracks.copy()

                    # Convert probabilities to a string
                    self.probabilityStr[trackID] = ','.join([f"{p:.4f}" for p in classifierOutput[trackNum]])
                    #Get Binary classifier prediction for CSV
                    for label in range(NUM_CLASSES_IN_CLASSIFIER):
                        if(binaryOutput[trackNum][label] > CLASSIFIER_CONFIDENCE_SCORE):
                            self.binaryLabel[trackID] = (-1 if label == 0 else 1)

                    with open(feature_csv, mode='a', newline='') as feature_file:
                        writer = csv.writer(feature_file)
                        writer.writerow(self.featureDatabaseDict[trackID])

        if (classifierOutput is not None and tracks is not None):
            # Loop through the tracks detected to label them as human/non-human
            for trackNum, trackName in enumerate(tracks):
                # Decode trackID from the trackName
                trackID = int(trackName[0])
                # Hold the track IDs detected in the current frame
                trackIDsInCurrFrame.append(trackID)
                # Track Velocity (radial) = (x * v_x + y*v_y + z*v_z)/ r
                trackVelocity = (trackName[1] * trackName[4] + trackName[2] * trackName[5] + trackName[3] * trackName[6]) \
                / math.sqrt(math.pow(trackName[1], 2) + math.pow(trackName[2], 2) + math.pow(trackName[3], 2))
                
                #Assigning labels
                if((PURE_MODEL_ENABLE == 1) or (self.frameCount <= 10)):
                    if (self.modelClass[trackID] == 0):
                        self.wasTargetHuman[trackID] = 1
                        self.classifierStr[trackID].setText("Human |" +  str(trackID))
                    #Dogs/Cats
                    elif (self.modelClass[trackID] == 1):
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Dog/Cat |" +  str(trackID))
                    #Fan
                    elif (self.modelClass[trackID] == 2):
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Fan |" +  str(trackID))
                    #Roomba
                    elif (self.modelClass[trackID] == 3):
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Roomba |" +  str(trackID))
                    #Unknown class
                    else:
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Unknown |" +  str(trackID))
                else:
                    #Updated classifier
                    # Update the tags if either the target has not already been detected as a human or the doppler is above the minimum velocity for classification. 
                    # This is designed to stop the tags from being assigned if target has already been detected as a human and becomes stationary.
                    if(not(self.wasTargetHuman[trackID] == 1 and abs(trackVelocity)<MIN_CLASSIFICATION_VELOCITY)):
                        for label in range(NUM_CLASSES_IN_CLASSIFIER):
                            if((classifierOutput[trackNum][label] > PROBABILITY_THRESHOLDS[label]) | (label == predicted_class)):
                                self.classifierTags[trackID].appendleft(predicted_class)

                    # Count the number of times each classifier tag appears
                    numHumanTags = sum(1 for i in self.classifierTags[trackID] if (i == 0))
                    numPetTags = sum(1 for i in self.classifierTags[trackID] if (i == 1))
                    numFanTags = sum(1 for i in self.classifierTags[trackID] if (i == 2))
                    numRoombaTags = sum(1 for i in self.classifierTags[trackID] if (i == 3))
                    self.classCounts[trackID] = [numHumanTags, numPetTags, numFanTags, numRoombaTags]
                    self.mostFrequentClass[trackID] = self.classCounts[trackID].index(max(self.classCounts[trackID]))
                    #print(numHumanTags, numPetTags, numFanTags, numRoombaTags)
                    top_two = sorted(enumerate(self.classCounts[trackID]), key=lambda x: -x[1])[:2]
                    class1, count1 = top_two[0]
                    class2, count2 = top_two[1]
                    if abs(count1 - count2) <= 2 and database_is_open and ((self.frameCount % VDB_QUERY_RATE) == 0):                       
                        #if((classifierOutput[trackNum][self.modelClass[trackID]] < PROBABILITY_THRESHOLDS[self.modelClass[trackID]]) & (classifierOutput[trackNum][self.modelClass[trackID]] > UNKNOWN_THRESHOLDS[self.modelClass[trackID]])): #ONLY QUERY IF THE PREDICTION IS NOT SURE + the result is not unknown
                        if((self.classCounts[trackID][self.mostFrequentClass[trackID]] < COUNT_THRESHOLDS[self.mostFrequentClass[trackID]])): #ONLY QUERY IF THE PREDICTION IS NOT SURE for a percentage of frames
                            ## self.featureDatabaseDict[trackID] to database query
                            ## Extract the first 80 columns as a list
                            vec = list(self.featureDatabaseDict[trackID])
                            self.database_queried[trackID] = "Queried"
                            previous_class = self.mostFrequentClass[trackID]

                            # Convert to string format for querying
                            vec_str = json.dumps(vec)  # JSON format for better compatibility
                            cur = connection.cursor() #open cursor to interact with the database
                            # SQL query to find the closest match
                            query = f"""
                                SELECT tag FROM featurels
                                WHERE vec <-> '{vec_str}'
                                < '{VDB_DISTANCE}'
                                LIMIT 100
                            """
                            cur.execute(query)
                            result = cur.fetchall()  # Fetch the first match, this stores the result

                            sorted_classifier_preds = sorted(
                                enumerate(classifierOutput[trackNum]), key=lambda x: -x[1]
                            )
                            
                            #Get the top 2 classifier predictions
                            top_two_indices = [sorted_classifier_preds[0][0], sorted_classifier_preds[1][0]]
                            #get the top two confience 
                            top_two_confidences = [sorted_classifier_preds[0][1], sorted_classifier_preds[1][1]]

                            #Tally the tags
                            from collections import Counter
                            tag_counts = Counter(tag - 1 for (tag,) in result)
                            self.most_common_tag = tag_counts.most_common(1)[0][0]

                            if len(result) < VDB_LENGTH: #USER CHOICE FOR LEN PARAM
                                self.vdbClass[trackID] = "unknown"
                                self.database_override[trackID] = "Overridden"
                                self.mostFrequentClass[trackID] = -1
                            else:
                                tag_counts = Counter(tag - 1 for (tag,) in result)
                                self.most_common_tag = tag_counts.most_common(1)[0][0]
                                if self.most_common_tag in top_two_indices:
                                    self.vdbClass[trackID] = self.most_common_tag
                                    self.mostFrequentClass[trackID] = self.vdbClass[trackID]
                                    self.database_override[trackID] = "Overridden"
                                else:
                                    # Check if both confidences are lower than threshold
                                    self.database_queried[trackID] = None
                                    self.database_override[trackID] = "Ignored"

                            print("Referenced database. Was:", previous_class, "| Now:", self.vdbClass[trackID])
                            previous_class = None
                            cur.close() #close conn and wait for re-open       
                        else: 
                            self.database_queried[trackID] = None
                            self.database_override[trackID] = None
                    else: 
                            self.database_queried[trackID] = None
                            self.database_override[trackID] = None
                    #Determine label for class with highest number of tags
                    if (self.mostFrequentClass[trackID] == 0):
                        self.wasTargetHuman[trackID] = 1
                        self.classifierStr[trackID].setText("Human |" +  str(trackID))
                    #Dogs/Cats
                    elif (self.mostFrequentClass[trackID] == 1):
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Dog/Cat |" +  str(trackID))
                    #Fan
                    elif (self.mostFrequentClass[trackID] == 2):
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Fan |" +  str(trackID))
                    #Roomba
                    elif (self.mostFrequentClass[trackID] == 3):
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Roomba |" +  str(trackID))
                    #Unknown class
                    else:
                        self.wasTargetHuman[trackID] = 0
                        self.classifierStr[trackID].setText("Unknown |" +  str(trackID))
                #binary classifier
                if(BINARY_CLASSIFIER_ENABLE == 1):
                    # Update the tags if ((classification probabilities have been generated by the radar for the current frame) AND 
                    # (either the target has not already been detected as a human or the doppler is above the minimum velocity for classification)). 
                    # This is designed to stop the tags from being assigned if target has already been detected as a human and becomes stationary.
                    if(classifierOutput[trackNum][0]!= 0.5 and not(self.wasTargetHuman[trackID] == 1 and abs(trackVelocity)<MIN_CLASSIFICATION_VELOCITY)):
                        # See if either label is above the minimum score needed for classification, it so, add the corresponding tag to the buffer
                        for label in range(NUM_CLASSES_IN_CLASSIFIER):
                            if(classifierOutput[trackNum][label] > CLASSIFIER_CONFIDENCE_SCORE):
                                self.classifierTags[trackID].appendleft(-1 if label == 0 else 1)
                    # Recompute sum of tags and number of unknown tags
                    # Sum the Tags (composed of +1 for one label, -1 for the other label and 0 for unknown) to see which label is dominant
                    sumOfTags = sum(self.classifierTags[trackID])
                    # Count the number of times there is an unknown tag in the tag buffer
                    numUnknownTags = sum(1 for i in self.classifierTags[trackID] if i == 0)

                    #Binary Classifier post processing code
                    # If we don't have enough tags for a decision or the number of tags for human/nonhuman are equal, make no decision 
                    if(numUnknownTags > MAX_NUM_UNKNOWN_TAGS_FOR_HUMAN_DETECTION or sumOfTags == 0):
                        self.wasTargetHuman[trackID] = 0 # Target was NOT detected to be human in the current frame, save for next frame
                        self.classifierStr[trackID].setText("Unknown Label |" +  str(trackID))
                    # If we have enough tags and the majority of them are for nonhuman, then detect nonhuman
                    elif(sumOfTags < 0):
                        self.wasTargetHuman[trackID] = 0 # Target was NOT detected to be human in the current frame, save for next frame
                        self.classifierStr[trackID].setText("Non-human |" +  str(trackID))
                    # If we have enough tags and the majority of them are for human, then detect human
                    elif(sumOfTags > 0):
                        self.wasTargetHuman[trackID] = 1 # Target WAS detected to be human in the current frame, save for next frame
                        self.classifierStr[trackID].setText("Human |" +  str(trackID))
                    
                # Populate string that will display a label      
                self.classifierStr[trackID].setX(trackName[1])
                self.classifierStr[trackID].setY(trackName[2])
                self.classifierStr[trackID].setZ(trackName[3] + 0.1) # Add 0.1 so it doesn't interfere with height text if enabled
                self.classifierStr[trackID].setVisible(True) 
                # Append row to CSV
                with open(predictions_csv, mode='a', newline='') as prediction_file:
                    writer = csv.writer(prediction_file)
                    writer.writerow([
                        self.local_time_string,
                        trackID,
                        self.modelClass[trackID],
                        self.vdbClass[trackID],
                        self.mostFrequentClass[trackID],
                        self.binaryLabel[trackID],
                        self.database_queried[trackID],
                        self.database_override[trackID],
                        self.probabilityStr[trackID],
                        self.classCounts[trackID]
                    ])
                            
            # Regardless of whether you get tracks in the current frame, if there were tracks in the previous frame, reset the
            # tag buffer and wasHumanTarget flag for tracks that aren't detected in the current frame but were detected in the previous frame
            tracksToShuffle = set(self.tracksIDsInPreviousFrame) - set(trackIDsInCurrFrame) 
            for track in tracksToShuffle:
                for frame in range(TAG_HISTORY_LEN):
                    self.classifierTags[track].appendleft(0) # fill the buffer with zeros to remove any history for the track
                self.wasTargetHuman[trackID] = 0 # Since target was not detected in current frame, reset the wasTargetHuman flag
            # Put the current tracks detected into the previous track list for the next frame
            self.tracksIDsInPreviousFrame = copy.deepcopy(trackIDsInCurrFrame)
