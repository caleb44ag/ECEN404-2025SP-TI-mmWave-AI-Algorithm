import os
import sys
import numpy as np
from pathlib import Path
import time 
import ast

import logging
log = logging.getLogger(__name__)

# Classifier Configurable
NUM_CLASSES_IN_CLASSIFIER = 2 #Number of classes board looks for (leave at 2)
CLASSIFIER_BUFFER_LEN = 30 
CLASSIFIER_CONFIDENCE_SCORE = 0.6 #probability threshold used for binary classifier
MIN_CLASSIFICATION_VELOCITY = 0.3 #necessary doppler movement needed to label a target
TAG_HISTORY_LEN = 10 # number of frames being considered
MAX_NUM_UNKNOWN_TAGS_FOR_HUMAN_DETECTION = 1 # used for binary classifier
CLASSIFIER_NUM_FEATURES = 4 

#set up thresholds
try:
    thresholdCSV = str(Path.cwd()) + "\\thresholds.txt"
    #Read the txt file and get the threshold lists
    with open(thresholdCSV) as input_file:
        thresholds = [ast.literal_eval(line) for line in input_file]
    PROBABILITY_THRESHOLDS = thresholds[0]
    COUNT_THRESHOLDS = thresholds[1]
    UNKNOWN_THRESHOLDS = thresholds[2]
    VDB_QUERY_RATE = thresholds[3]
    VDB_IP = thresholds[4]
except FileNotFoundError:
    print(f"Error: File not found at {thresholdCSV}")    
    #probability thresholds 
    PROBABILITY_THRESHOLDS = [0.5, 0.5, 0.5, 0.5]
    #min prob thresholds for UNKNOWN
    UNKNOWN_THRESHOLDS = [0.3, 0.3, 0.3, 0.3]
    #count thresholds for each class (how many of a certain number of frames must be X class for it to classify)
    COUNT_THRESHOLDS = [5,5,5,5]#[TAG_HISTORY_LEN * 0.5, TAG_HISTORY_LEN * 0.75, TAG_HISTORY_LEN * (3/20), TAG_HISTORY_LEN * (3/20)]
    VDB_IP = "ignore" #replace 0 with database ip address if database is being used 
except Exception as e:
    print(f"An error occurred: {e}")
    #probability thresholds 
    PROBABILITY_THRESHOLDS = [0.5, 0.5, 0.5, 0.5]
    #min prob thresholds for UNKNOWN
    UNKNOWN_THRESHOLDS = [0.3, 0.3, 0.3, 0.3]
    #count thresholds for each class (how many of a certain number of frames must be X class for it to classify)
    COUNT_THRESHOLDS = [5,5,5,5]#[TAG_HISTORY_LEN * 0.5, TAG_HISTORY_LEN * 0.75, TAG_HISTORY_LEN * (3/20), TAG_HISTORY_LEN * (3/20)]
    VDB_IP = "ignore" #replace 0 with database ip address if database is being used 
    

#Configuration post processing values for IWRL6432 demo
PURE_MODEL_ENABLE = 0
#PROBABILITY_THRESHOLDS = [0.5, 0.5, 0.5, 0.5]
#COUNT_THRESHOLDS = [5, 5, 5, 5] # number of frames that must be counted for class to be classified (if no class reaches the threshold, uses the most counted class)
#UNKNOWN_THRESHOLDS = [0.3, 0.3, 0.3, 0.3] #min prob thresholds for UNKNOWN labeling by the database
#VDB_IP = "34.134.64.209"#"0" #replace 0 with database ip address if database is being used




def fixStringCase(st):
    return ''.join(''.join([w[0].upper(), w[1:].lower()]) for w in st.split())

def next_power_of_2(x):  
    return 1 if x == 0 else 2**(x - 1).bit_length()

def median(lst):
    lst.sort()
    if len(lst) % 2 == 1:
        return lst[len(lst)//2]
    else:
        return (lst[len(lst)//2-1] + lst[len(lst)//2])/2

# Convert 3D Spherical Points to Cartesian
# Assumes sphericalPointCloud is an numpy array with at LEAST 3 dimensions
# Order should be Range, Elevation, Azimuth
def sphericalToCartesianPointCloud(sphericalPointCloud):
    shape = sphericalPointCloud.shape
    cartesianPointCloud = sphericalPointCloud.copy()
    if (shape[1] < 3):
        log.error('Error: Failed to convert spherical point cloud to cartesian due to numpy array with too few dimensions')
        return sphericalPointCloud

    # Compute X
    # Range * sin (azimuth) * cos (elevation)
    cartesianPointCloud[:,0] = sphericalPointCloud[:,0] * np.sin(sphericalPointCloud[:,1]) * np.cos(sphericalPointCloud[:,2]) 
    # Compute Y
    # Range * cos (azimuth) * cos (elevation)
    cartesianPointCloud[:,1] = sphericalPointCloud[:,0] * np.cos(sphericalPointCloud[:,1]) * np.cos(sphericalPointCloud[:,2]) 
    # Compute Z
    # Range * sin (elevation)
    cartesianPointCloud[:,2] = sphericalPointCloud[:,0] * np.sin(sphericalPointCloud[:,2])
    return cartesianPointCloud
